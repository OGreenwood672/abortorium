import{a as t}from"../chunks/entry.3jEPv68W.js";export{t as start};
