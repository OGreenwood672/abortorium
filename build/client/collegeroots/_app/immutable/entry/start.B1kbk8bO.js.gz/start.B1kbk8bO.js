import{a as t}from"../chunks/entry.H7K0CHKP.js";export{t as start};
